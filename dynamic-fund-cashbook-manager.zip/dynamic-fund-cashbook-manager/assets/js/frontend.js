(function($){
	$(function(){ /* placeholder */ });
})(jQuery);