Fund Manager Pro
=================

Shortcode: [fmp_member_payments]

User Roles:
- Administrator: manage_options
- Accountant: fmp_manage_funds
- Member: fmp_member (view own history)